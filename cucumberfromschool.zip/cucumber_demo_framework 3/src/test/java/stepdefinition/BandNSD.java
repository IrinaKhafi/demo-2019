package stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import framework.webPages.BandNLandingPage;
import framework.webPages.BandNOutletPage;

public class BandNSD {
    private BandNLandingPage lPage = new BandNLandingPage();
    private BandNOutletPage oPage = new BandNOutletPage();

    @Given("^I am on landing page$")
    public void iAmOnLpage(){
        SharedSD.getDriver();

    }
    @When("^I verify all the books info$")
    public void iGetAllTheInfo() throws InterruptedException{
        lPage.clickOnOutlet();
        oPage.clickOnBestSeller();

    }
    @Then("^I print the info out$")
    public void allInfoOut(){

    }
}
