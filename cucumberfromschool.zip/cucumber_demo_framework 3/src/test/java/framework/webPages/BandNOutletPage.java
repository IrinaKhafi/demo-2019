package framework.webPages;

import org.openqa.selenium.By;

public class BandNOutletPage extends BasePage{
    private By bestSellrsButton = By.xpath("//li[@class='focus']//a[contains(text(),'Bestsellers')]");
    private By bookName = By.xpath("//a[@xpath=1]");

    public void clickOnBestSeller(){
        clickOn(bestSellrsButton);
        clickOn(bookName);
    }

}
