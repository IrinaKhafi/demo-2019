package framework.webPages;

import org.openqa.selenium.By;

public class BandNLandingPage extends BasePage {

private By sale = By.xpath("//body[@class='homepage hpv3 prior-load']/header[@id='globalHeader']/nav[@id='primaryNav']/ul[@id='nav']/li[@id='topNav13']/a[1]");
private By outletButton = By.xpath("//div[@class='col-lg-4']//a[contains(text(),'B&N Outlet')]");

public void clickOnOutlet()throws InterruptedException{
    mouseOver(sale);
    Thread.sleep(3000);
    clickOn(outletButton);
}

}
